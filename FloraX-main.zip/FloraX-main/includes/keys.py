mongo = "mongodb+srv://pottiflorax:rg5MiY4Fmp0Z2BxW@florax.vgqpqiu.mongodb.net/?retryWrites=true&w=majority"
openweathermap = '077c227de8d61547f89391de738e5697'
plant_id = 'JJ7ij5UUSbIZ5GcAzbGpuaB8NdOgAcdcxQa14AyDipb4GcPpuO'